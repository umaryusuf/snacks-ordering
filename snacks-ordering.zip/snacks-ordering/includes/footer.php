<footer class="text-center bg-primary">
	&copy; Copyright 2017 All right reserved
</footer>